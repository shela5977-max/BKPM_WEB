<footer class="bg-dark text-white text-center py-3 mt-5">
    <p class="mb-0">
        &copy; 2026 Sistem Informasi Akademik
    </p>
</footer>

<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

</body>
</html>
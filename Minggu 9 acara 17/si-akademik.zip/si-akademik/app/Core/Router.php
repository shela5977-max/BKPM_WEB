
/*
|--------------------------------------------------------------------------
| API BUKU - RESTFUL API ACARA 17 MENGGUNAKAN ROUTER
|--------------------------------------------------------------------------
*/

if (
    preg_match(
        '#^/api/buku(?:/([^/]+))?/?$#',
        $uri
    ) === 1
) {
    require_once __DIR__ . '/../app/Core/Router.php';
    require_once __DIR__ . '/../app/controllers/BukuController.php';

    $router = new Router();
    $bukuController = new BukuController();

    // Mendaftarkan resource Buku ke Router
    $router->resource('/api/buku', $bukuController);

    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if (!$router->dispatch($uri, $method)) {
        http_response_code(405);
        header('Content-Type: application/json; charset=utf-8');

        echo json_encode([
            'success' => false,
            'message' => 'Metode HTTP tidak diizinkan.',
            'data' => null
        ], JSON_PRETTY_PRINT);
    }

    exit;
}

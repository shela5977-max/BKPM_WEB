
<?php

require_once __DIR__ . '/../Core/Database.php';

class Buku
{
    private PDO $pdo;

    public function __construct()
    {
        $this->pdo = Database::getInstance();
    }

    // Mengambil semua data buku
    public function getAll(): array
    {
        $sql = "SELECT * FROM buku ORDER BY id ASC";
        $stmt = $this->pdo->query($sql);

        return $stmt->fetchAll();
    }

    // Mengambil data buku berdasarkan ID
    public function getById(int $id): array|false
    {
        $sql = "SELECT * FROM buku WHERE id = :id";

        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            'id' => $id
        ]);

        return $stmt->fetch();
    }

    // Memeriksa apakah kode buku sudah digunakan
    public function existsKode(
        string $kodeBuku,
        ?int $excludeId = null
    ): bool {
        if ($excludeId !== null) {
            $sql = "SELECT COUNT(*) FROM buku
                    WHERE kode_buku = :kode
                    AND id != :id";

            $stmt = $this->pdo->prepare($sql);

            $stmt->execute([
                'kode' => $kodeBuku,
                'id' => $excludeId
            ]);
        } else {
            $sql = "SELECT COUNT(*) FROM buku
                    WHERE kode_buku = :kode";

            $stmt = $this->pdo->prepare($sql);

            $stmt->execute([
                'kode' => $kodeBuku
            ]);
        }

        return (int) $stmt->fetchColumn() > 0;
    }

    // Menambahkan data buku
    public function create(array $data): int
    {
        $sql = "INSERT INTO buku
                (kode_buku, judul, penulis, tahun_terbit)
                VALUES
                (:kode_buku, :judul, :penulis, :tahun_terbit)";

        $stmt = $this->pdo->prepare($sql);

        $stmt->execute([
            'kode_buku' => $data['kode_buku'],
            'judul' => $data['judul'],
            'penulis' => $data['penulis'],
            'tahun_terbit' => $data['tahun_terbit']
        ]);

        return (int) $this->pdo->lastInsertId();
    }

    // Memperbarui data buku
    public function update(int $id, array $data): bool
    {
        $sql = "UPDATE buku
                SET kode_buku = :kode_buku,
                    judul = :judul,
                    penulis = :penulis,
                    tahun_terbit = :tahun_terbit
                WHERE id = :id";

        $stmt = $this->pdo->prepare($sql);

        $stmt->execute([
            'kode_buku' => $data['kode_buku'],
            'judul' => $data['judul'],
            'penulis' => $data['penulis'],
            'tahun_terbit' => $data['tahun_terbit'],
            'id' => $id
        ]);

        return $stmt->rowCount() > 0;
    }

    // Menghapus data buku
    public function delete(int $id): bool
    {
        $sql = "DELETE FROM buku WHERE id = :id";

        $stmt = $this->pdo->prepare($sql);

        $stmt->execute([
            'id' => $id
        ]);

        return $stmt->rowCount() > 0;
    }
}


<?php

require_once __DIR__ . '/../models/Buku.php';

class BukuController
{
    private Buku $buku;

    public function __construct()
    {
        $this->buku = new Buku();
    }

    // Mengirim respons JSON
    private function response(
        int $status,
        string $message,
        mixed $data = null
    ): void {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');

        echo json_encode([
            'success' => $status < 400,
            'message' => $message,
            'data' => $data
        ], JSON_PRETTY_PRINT);

        exit;
    }

    // Membaca JSON dari request
    private function getInput(): array
    {
        $input = json_decode(
            file_get_contents('php://input'),
            true
        );

        return is_array($input) ? $input : [];
    }

    // Membaca dan memvalidasi ID dari URL
    private function getId(): int|false
    {
        if (!isset($_GET['id'])) {
            return false;
        }

        $id = filter_var(
            $_GET['id'],
            FILTER_VALIDATE_INT
        );

        if ($id === false || $id < 1) {
            return false;
        }

        return $id;
    }

    // Validasi data buku
    private function validate(array $data): ?string
    {
        $required = [
            'kode_buku',
            'judul',
            'penulis',
            'tahun_terbit'
        ];

        foreach ($required as $field) {
            if (
                !isset($data[$field]) ||
                trim((string) $data[$field]) === ''
            ) {
                return "Field {$field} wajib diisi.";
            }
        }

        if (!ctype_digit((string) $data['tahun_terbit'])) {
            return 'Tahun terbit harus berupa angka.';
        }

        $tahun = (int) $data['tahun_terbit'];

        if ($tahun < 1901 || $tahun > 2155) {
            return 'Tahun terbit harus antara 1901 dan 2155.';
        }

        return null;
    }

    // GET /api/buku atau GET /api/buku/1
    public function index(): void
    {
        try {
            if (isset($_GET['id'])) {
                $id = $this->getId();

                if ($id === false) {
                    $this->response(
                        400,
                        'ID buku tidak valid.'
                    );
                }

                $data = $this->buku->getById($id);

                if (!$data) {
                    $this->response(
                        404,
                        'Buku tidak ditemukan.'
                    );
                }

                $this->response(
                    200,
                    'Data buku berhasil diambil.',
                    $data
                );
            }

            $data = $this->buku->getAll();

            $this->response(
                200,
                'Data buku berhasil diambil.',
                $data
            );
        } catch (Throwable $e) {
            $this->response(
                500,
                'Terjadi kesalahan pada server.'
            );
        }
    }

    // POST /api/buku
    public function store(): void
    {
        $data = $this->getInput();

        $error = $this->validate($data);

        if ($error !== null) {
            $this->response(422, $error);
        }

        try {
            if ($this->buku->existsKode($data['kode_buku'])) {
                $this->response(
                    409,
                    'Kode buku sudah digunakan.'
                );
            }

            $id = $this->buku->create($data);

            $this->response(
                201,
                'Buku berhasil ditambahkan.',
                ['id' => $id]
            );
        } catch (Throwable $e) {
            $this->response(
                500,
                'Gagal menambahkan buku.'
            );
        }
    }

    // PUT /api/buku/1
    public function update(): void
    {
        $id = $this->getId();

        if ($id === false) {
            $this->response(
                400,
                'ID buku tidak valid.'
            );
        }

        $data = $this->getInput();

        $error = $this->validate($data);

        if ($error !== null) {
            $this->response(422, $error);
        }

        try {
            if (!$this->buku->getById($id)) {
                $this->response(
                    404,
                    'Buku tidak ditemukan.'
                );
            }

            if (
                $this->buku->existsKode(
                    $data['kode_buku'],
                    $id
                )
            ) {
                $this->response(
                    409,
                    'Kode buku sudah digunakan.'
                );
            }

            $this->buku->update($id, $data);

            $this->response(
                200,
                'Data buku berhasil diperbarui.'
            );
        } catch (Throwable $e) {
            $this->response(
                500,
                'Gagal memperbarui data buku.'
            );
        }
    }

    // DELETE /api/buku/1
    public function destroy(): void
    {
        $id = $this->getId();

        if ($id === false) {
            $this->response(
                400,
                'ID buku tidak valid.'
            );
        }

        try {
            if (!$this->buku->getById($id)) {
                $this->response(
                    404,
                    'Buku tidak ditemukan.'
                );
            }

            $this->buku->delete($id);

            $this->response(
                200,
                'Buku berhasil dihapus.'
            );
        } catch (Throwable $e) {
            $this->response(
                500,
                'Gagal menghapus buku.'
            );
        }
    }
}
